package com.project.knpark.vo;

import java.sql.Date;

import lombok.Data;

@Data
public class Admin {
	private String aid;
	private String apw;
	private String aname;
	private String agroup;
	private Date   ardate;
}
